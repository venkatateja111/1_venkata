<?php
 $con = mysqli_connect("localhost","root", "", "movies") or die(mysqli_error($con));
 session_start();
 ?>