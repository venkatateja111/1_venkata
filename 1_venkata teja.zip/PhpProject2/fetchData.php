<?php
	
	$name = "venkata";
	$age = 20;
	$mobile = 8269225755;
	
	$ar = Array('nm'=>"$name",'ag'=>"$age",'mb'=>"$mobile");
	
		array_push($ar,"");
		
	

	echo json_encode($ar);

?><?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

