<?php
require("common.php");
if (isset($_SESSION['email_id'])) {
    header('location: index.php');
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
       
        <title>Signup | Life Style Store</title>
       <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css" type="text/css">
        <script type="text/javascript" src="bootstrap-3.3.7-dist/js/jquery.js"></script>
        <script type="text/javascript" src="bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
        <script type="text/javascript" src="vali.js"></script>
        <link rel="stylesheet" type="text/css" href="index.css">
        <style>
            body{
                background-color: rgba(0,0,0,0.8);
                background: url("img/webpic4.jpg");
                
            }
            h2{
                color: yellow; 
            }
            label{
                color: black;
            }
            input:focus{
                background-color: wheat;
            }
            button{
                 border: none!important;
                 border-radius: 40px!important;
            }
            button:hover{
                background-color: green!important;
            }
            
            .alert {
                width:50%;  
               margin-left: 300px;
               }
             .alert button:hover
               {
               background-color:  white;
                  }
              label{
                  padding-left: 10px;
                  }
</style>
        
            
    </head>
    <body>
        
        <div><?php include 'header.php'; ?></div>
        
        <br><br><br><br><br><br>
        <div class="container">
     <div class="row">
    <div class="container" style="display:none;" id="myAlert">
        
        <div class="alert alert-warning alert-dismissable " id="myAlert2">
            <button type='button' class='close' data-dismiss='alert'   aria-hidden='true'>&times;</button>
            please enter only letters in first name
        </div>

    </div>
         <div class="container" style="display:none;" id="myAlert3">
        
        <div class="alert alert-warning alert-dismissable " id="myAlert4">
            <button type='button' class='close' data-dismiss='alert'   aria-hidden='true'>&times;</button>
            please enter minimum 5 letters in first name
        </div>

    </div>
         <div class="container" style="display:none;" id="myAlert5">
        
        <div class="alert alert-warning alert-dismissable " id="myAlert6">
            <button type='button' class='close' data-dismiss='alert'   aria-hidden='true'>&times;</button>
            please enter only letters in last name
        </div>

    </div>
          <div class="container" style="display:none;" id="myAlert7">
        
        <div class="alert alert-warning alert-dismissable " id="myAlert8">
            <button type='button' class='close' data-dismiss='alert'   aria-hidden='true'>&times;</button>
            please enter minimum 5 letters in last name
        </div>

    </div>
         <div class="container" style="display:none;" id="myAlert9">
        
        <div class="alert alert-warning alert-dismissable " id="myAlert10">
            <button type='button' class='close' data-dismiss='alert'   aria-hidden='true'>&times;</button>
            please include @ in your email
        </div>

    </div>
         <div class="container" style="display:none;" id="myAlert11">
        
        <div class="alert alert-warning alert-dismissable " id="myAlert12">
            <button type='button' class='close' data-dismiss='alert'   aria-hidden='true'>&times;</button>
            please include . in your email
        </div>

    </div>
         <div class="container" style="display:none;" id="myAlert15">
        
        <div class="alert alert-warning alert-dismissable " id="myAlert16">
            <button type='button' class='close' data-dismiss='alert'   aria-hidden='true'>&times;</button>
            please enter password
        </div>

    </div>
         <div class="container" style="display:none;" id="myAlert13">
        
        <div class="alert alert-warning alert-dismissable " id="myAlert14">
            <button type='button' class='close' data-dismiss='alert'   aria-hidden='true'>&times;</button>
            please enter 10 digit phone number
        </div>

    </div>
    </div>
</div>
        <div class="col-md-offset-1">
        <div class="container-fluid" id="content">
            <div class="row">
                <div class="container">
                    <div class="col-lg-4 col-lg-offset-4 col-md-6 col-md-offset-3">
                        
                            <h2> SIGN UP</h2>

                       
                            <form action="signup_script.php" method="POST">
                            <div class="form-group">
                                <label>First Name :</label>
                                <input class="form-control" placeholder="first_name" name="first_name">
                            </div>
                            <div class="form-group">
                                <label>Last Name :</label>
                                <input class="form-control" placeholder="last_name" name="last_name">
                            </div>
                            <div class="form-group">
                                <label>Email Id :</label>
                                <input  class="form-control"  placeholder="email_id"   name="email_id">
                            </div>
                            <div class="form-group">
                                <label>Password :</label>
                                <input type="password" class="form-control" placeholder="Password" pattern=".{6,}" name="password" >
                            </div>
                            <div class="form-group">
                                <label>Phone :</label>
                                <input type="number" class="form-control"  placeholder="phone"  maxlength="10" size="10" name="phone">
                            </div>
                                <button onclick="abc();return false;" type="submit" name="submit" class="btn btn-primary btn-block">Submit</button>
                                <b><p style="color: black"><?php echo $_GET['error']??''; ?></p></b>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        </div>
        <div class="navbar-fixed-bottom">
            <?php include "footer.php"; ?>
        
        </div>
    </body>
</html>


